<?php

$_lang['msoptionsprice_prop_limit'] = 'Ограничение вывода Предметов на странице';
$_lang['msoptionsprice_prop_outputSeparator'] = 'Разделитель вывода строк';
$_lang['msoptionsprice_prop_sortBy'] = 'Поле сортировки';
$_lang['msoptionsprice_prop_sortDir'] = 'Направление сортировки';
$_lang['msoptionsprice_prop_tpl'] = 'Чанк оформления каждого ряда Предметов';
$_lang['msoptionsprice_prop_toPlaceholder'] = 'Усли указан этот параметр, то результат будет сохранен в плейсхолдер, вместо прямого вывода на странице';
$_lang['msoptionsprice_prop_where'] = 'Строка, закодированная в JSON, с дополнительными условиями выборки';
$_lang['msoptionsprice_prop_showLog'] = 'Показывать дополнительную информацию о работе сниппета. Только для авторизованных в контексте "mgr"';
$_lang['msoptionsprice_prop_returnIds'] = 'Возвращать строку с id обьектов, вместо оформленных чанков';
$_lang['msoptionsprice_prop_showZeroPrice'] = 'Показывать объекты с нулевой ценой';
$_lang['msoptionsprice_prop_showZeroCount'] = 'Показывать объекты с нулевым количеством';
$_lang['msoptionsprice_prop_wrapIfEmpty'] = 'Включает вывод чанка-обертки (tplWrapper) даже если результатов нет';
$_lang['msoptionsprice_prop_product'] = 'Идентификатор продукта. Если не указан, используется id текущего документа';
$_lang['msoptionsprice_prop_sortby'] = 'Сортировка выборки';
$_lang['msoptionsprice_prop_sortdir'] = 'Направление сортировки';
$_lang['msoptionsprice_prop_type'] = 'Тип объекта';
$_lang['msoptionsprice_prop_frontendJs'] = 'Файл с javascript';
$_lang['msoptionsprice_prop_frontendCss'] = 'Файл с css';
$_lang['msoptionsprice_prop_actionUrl'] = 'Url action.php';
$_lang['msoptionsprice_prop_includeThumbs'] = 'Список размеров превью для выборки, через запятую. Например: "120x90,360x240" дадут плейслолдеры [[+120x90]] и [[+360x240]].';
$_lang['msoptionsprice_prop_processOptions'] = 'Обрабатывать опции модификации. Если не указан, используется просто массив значений';
$_lang['msoptionsprice_prop_processColors'] = 'Обрабатывать цвета опции пакета "msOptionsColor".';

