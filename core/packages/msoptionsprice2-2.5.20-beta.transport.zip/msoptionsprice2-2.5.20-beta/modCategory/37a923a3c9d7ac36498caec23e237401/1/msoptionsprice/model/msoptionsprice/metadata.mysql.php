<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'msopModification',
  ),
  'xPDOObject' => 
  array (
    0 => 'msopModificationOption',
    1 => 'msopModificationImage',
  ),
);