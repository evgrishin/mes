<?php

/* Errors */

$_lang['msoptionsprice_err_system'] = 'Системная ошибка';
$_lang['msoptionsprice_err_unknown'] = 'Неизвестная ошибка';
$_lang['msoptionsprice_err_value'] = 'Неверное значение';
$_lang['msoptionsprice_err_lock'] = 'Эта операция заблокирована';
$_lang['msoptionsprice_err_ns'] = 'Это поле обязательно';
$_lang['msoptionsprice_err_ae'] = 'Это поле должно быть уникально';
$_lang['msoptionsprice_err_object_exists'] = 'Объект уже существует';
$_lang['msoptionsprice_err_object_not_exists'] = 'Объект не существует';
$_lang['msoptionsprice_err_action_ns'] = 'Не указан ключ (action)';
$_lang['msoptionsprice_err_form_key_ns'] = 'Не указан ключ формы (form_key)';
$_lang['msoptionsprice_err_properties_ns'] = 'Не указаны свойства (properties)';
$_lang['msoptionsprice_err_action_un'] = 'Неизвестный ключ (action)';
$_lang['msoptionsprice_err_chunk_ns'] = 'Не указан чанк для обработки';
$_lang['msoptionsprice_err_chunk_nf'] = 'Не могу найти указанный чанк "[[+name]]"';
$_lang['msoptionsprice_err_snippet_ns'] = 'Не указан сниппет для обработки';
$_lang['msoptionsprice_err_snippet_nf'] = 'Не могу найти указанный сниппет "[[+name]]" для обработки';
$_lang['msoptionsprice_err_field_nf'] = 'Не указано поле "[[+field]]"';
$_lang['msoptionsprice_err_modify_exists'] = 'Модификация с данными свойствами уже существует';

$_lang['msoptionsprice_err_available_count'] = 'Нет доступного количества';
$_lang['msoptionsprice_err_available_remains'] = 'Доступно - [[+count]] шт.';
$_lang['msoptionsprice_err_available_modification'] = 'Нет доступной модификации';

$_lang['msopModificationOption_err_save'] = 'Ошибка сохранения';
